from microEye.hardware.stages.kinesis.kinesis import KinesisView, KinesisXY
