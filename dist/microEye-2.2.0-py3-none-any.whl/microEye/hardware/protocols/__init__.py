from microEye.hardware.protocols.actions import WeakObjects
from microEye.hardware.protocols.designer import ExperimentDesigner
